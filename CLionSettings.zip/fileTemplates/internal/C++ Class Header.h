#[[#ifndef]]# ${NAME.toUpperCase()}_HPP
#[[#define]]# ${NAME.toUpperCase()}_HPP

${NAMESPACES_OPEN}

class ${NAME}
{

};

${NAMESPACES_CLOSE}

#[[#endif]]# //${NAME.toUpperCase()}_HPP
