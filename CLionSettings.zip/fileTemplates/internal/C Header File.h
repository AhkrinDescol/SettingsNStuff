#[[#ifndef]]# ${NAME}
#[[#define]]# ${NAME}

#[[#endif]]# //${NAME}
